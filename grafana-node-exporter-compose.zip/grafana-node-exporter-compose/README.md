# Grafana + Prometheus + Node Exporter Docker Compose

## Start

```bash
docker compose up -d
```

## Open

Grafana:

```text
http://localhost:3000
```

Default login:

```text
admin / admin
```

Prometheus:

```text
http://localhost:9090
```

Node Exporter metrics:

```text
http://localhost:9100/metrics
```

## Import Dashboard

In Grafana:

```text
Dashboards → Import
```

Use dashboard ID:

```text
1860
```

Select the Prometheus data source.

## Stop

```bash
docker compose down
```

## Stop and remove data

```bash
docker compose down -v
```
